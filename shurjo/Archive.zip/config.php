<?php

	define('USERNAME','sp_sandbox');
	define('PASSWORD','pyyk97hu&6u6');
	define('TESTMODE',TRUE);
	define('PREFIX','NOK');
