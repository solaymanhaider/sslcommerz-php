<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Payment Successful</title>
	<link rel="stylesheet" href="./assets/app.css">
</head>
<body>
	<div class="alert_wrap">
		<div class="alert_box">
			<div class="alert_content">
				<div class="alert_icon">
					<img src="./assets/like.gif" alt="Successful">
				</div>
				<h2>Payment Successful</h2>
			</div>
		</div>
	</div>
</body>
</html>